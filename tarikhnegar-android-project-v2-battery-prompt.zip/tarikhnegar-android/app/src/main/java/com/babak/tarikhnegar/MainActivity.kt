package com.babak.tarikhnegar

import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.content.Context
import android.provider.Settings
import android.view.WindowManager
import android.provider.MediaStore
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import java.io.IOException

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private var filePathCallback: android.webkit.ValueCallback<Array<Uri>>? = null
    private val selectedUris = mutableListOf<Uri>()
    private val pickRequest = 7102

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        webView = WebView(this)
        setContentView(webView)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.allowFileAccess = true
        webView.settings.allowContentAccess = true
        webView.addJavascriptInterface(AndroidBridge(), "AndroidBridge")
        webView.webViewClient = WebViewClient()
        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                view: WebView?,
                callback: android.webkit.ValueCallback<Array<Uri>>?,
                params: FileChooserParams?
            ): Boolean {
                filePathCallback?.onReceiveValue(null)
                filePathCallback = callback
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "image/*"
                    putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
                }
                return try {
                    startActivityForResult(intent, pickRequest)
                    true
                } catch (e: Exception) {
                    filePathCallback = null
                    Toast.makeText(this@MainActivity, "باز کردن انتخاب‌گر عکس ممکن نشد", Toast.LENGTH_LONG).show()
                    false
                }
            }
        }
        if (savedInstanceState == null) webView.loadUrl("file:///android_asset/index.html")
        else webView.restoreState(savedInstanceState)
    }

    @Deprecated("Deprecated in Android, retained for broad WebView compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != pickRequest) return
        val callback = filePathCallback ?: return
        filePathCallback = null
        selectedUris.clear()
        if (resultCode == RESULT_OK && data != null) {
            val clip = data.clipData
            if (clip != null) {
                for (i in 0 until clip.itemCount) selectedUris.add(clip.getItemAt(i).uri)
            } else data.data?.let { selectedUris.add(it) }
            val flags = data.flags and (Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
            selectedUris.forEach { uri ->
                try { contentResolver.takePersistableUriPermission(uri, flags) } catch (_: Exception) { }
            }
        }
        callback.onReceiveValue(if (selectedUris.isEmpty()) null else selectedUris.toTypedArray())
    }

    inner class AndroidBridge {
        @JavascriptInterface
        fun saveImage(index: Int, dataUrl: String, outputName: String, replaceOriginal: Boolean): Boolean {
            return try {
                val comma = dataUrl.indexOf(',')
                if (comma < 0) return false
                val bytes = Base64.decode(dataUrl.substring(comma + 1), Base64.DEFAULT)
                if (replaceOriginal) {
                    val uri = selectedUris.getOrNull(index) ?: return false
                    val stream = contentResolver.openOutputStream(uri, "wt") ?: return false
                    stream.use { it.write(bytes); it.flush() }
                } else {
                    val values = ContentValues().apply {
                        put(MediaStore.Images.Media.DISPLAY_NAME, outputName)
                        put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                        put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/TarikhNegar")
                    }
                    val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return false
                    contentResolver.openOutputStream(uri, "w")?.use { it.write(bytes); it.flush() } ?: return false
                }
                true
            } catch (_: IOException) { false } catch (_: SecurityException) { false } catch (_: Exception) { false }
        }

        @JavascriptInterface
        fun selectedCount(): Int = selectedUris.size

        @JavascriptInterface
        fun setKeepScreenOn(enabled: Boolean) {
            runOnUiThread {
                if (enabled) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            }
        }

        @JavascriptInterface
        fun isBatterySetupDone(): Boolean {
            return getSharedPreferences("tarikhnegar_settings", Context.MODE_PRIVATE)
                .getBoolean("battery_setup_done", false)
        }

        @JavascriptInterface
        fun markBatterySetupDone() {
            getSharedPreferences("tarikhnegar_settings", Context.MODE_PRIVATE)
                .edit().putBoolean("battery_setup_done", true).apply()
        }

        @JavascriptInterface
        fun openBatterySettings() {
            runOnUiThread {
                try {
                    startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                } catch (_: Exception) {
                    try {
                        startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                            data = Uri.parse("package:$packageName")
                        })
                    } catch (_: Exception) {
                        Toast.makeText(this@MainActivity, "باز کردن تنظیمات باتری ممکن نشد", Toast.LENGTH_LONG).show()
                    }
                }
            }
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        webView.saveState(outState)
        super.onSaveInstanceState(outState)
    }

    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }
}
