package com.babak.tarikhnegar

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder

class ProcessingForegroundService : Service() {
    private val channelId = "tarikhnegar_active_processing"
    private val notificationId = 2208

    override fun onCreate() {
        super.onCreate()
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(
                channelId,
                "پردازش فعال عکس‌ها",
                NotificationManager.IMPORTANCE_LOW
            ).apply { description = "نمایش وضعیت اجرای پردازش عکس‌ها" }
            (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val launchIntent = packageManager.getLaunchIntentForPackage(packageName)
        val pendingIntent = launchIntent?.let {
            PendingIntent.getActivity(
                this,
                1,
                it,
                PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
            )
        }
        val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, channelId) else Notification.Builder(this)
        builder.setSmallIcon(applicationInfo.icon)
            .setContentTitle("تاریخ‌نگار فارسی")
            .setContentText("در حال پردازش عکس‌ها…")
            .setOngoing(true)
            .setOnlyAlertOnce(true)
        if (pendingIntent != null) builder.setContentIntent(pendingIntent)
        startForeground(notificationId, builder.build())
        return START_NOT_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
