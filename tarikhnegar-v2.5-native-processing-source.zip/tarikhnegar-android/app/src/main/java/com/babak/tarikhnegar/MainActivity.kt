package com.babak.tarikhnegar

import android.app.Activity
import android.Manifest
import android.content.pm.PackageManager
import android.os.CancellationSignal
import android.util.Size
import org.json.JSONArray
import org.json.JSONObject
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.os.Build
import android.content.ContentValues
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.PowerManager
import android.content.Context
import android.provider.Settings
import android.view.WindowManager
import android.provider.MediaStore
import android.util.Base64
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Typeface
import androidx.exifinterface.media.ExifInterface
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import java.io.IOException

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private var filePathCallback: android.webkit.ValueCallback<Array<Uri>>? = null
    private val selectedUris = mutableListOf<Uri>()
    private val pickRequest = 7102
    private val galleryPermissionRequest = 7104
    private val notificationRequest = 7103
    private val notificationChannelId = "tarikhnegar_processing"
    private var processingWakeLock: PowerManager.WakeLock? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        webView = WebView(this)
        setContentView(webView)
        webView.settings.javaScriptEnabled = true
        webView.setRendererPriorityPolicy(WebView.RENDERER_PRIORITY_BOUND, true)
        webView.isFocusable = true
        webView.isFocusableInTouchMode = true
        webView.settings.domStorageEnabled = true
        webView.settings.allowFileAccess = true
        webView.settings.allowContentAccess = true
        webView.addJavascriptInterface(AndroidBridge(), "AndroidBridge")
        webView.webViewClient = WebViewClient()
        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                view: WebView?,
                callback: android.webkit.ValueCallback<Array<Uri>>?,
                params: FileChooserParams?
            ): Boolean {
                filePathCallback?.onReceiveValue(null)
                filePathCallback = callback
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "image/*"
                    putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
                }
                return try {
                    startActivityForResult(intent, pickRequest)
                    true
                } catch (e: Exception) {
                    filePathCallback = null
                    Toast.makeText(this@MainActivity, "باز کردن انتخاب‌گر عکس ممکن نشد", Toast.LENGTH_LONG).show()
                    false
                }
            }
        }
        createNotificationChannel()
        if (savedInstanceState == null) webView.loadUrl("file:///android_asset/index.html")
        else webView.restoreState(savedInstanceState)
    }

    private fun hasImageReadPermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= 34) {
            checkSelfPermission(Manifest.permission.READ_MEDIA_IMAGES) == PackageManager.PERMISSION_GRANTED ||
                checkSelfPermission("android.permission.READ_MEDIA_VISUAL_USER_SELECTED") == PackageManager.PERMISSION_GRANTED
        } else if (Build.VERSION.SDK_INT >= 33) {
            checkSelfPermission(Manifest.permission.READ_MEDIA_IMAGES) == PackageManager.PERMISSION_GRANTED
        } else {
            checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
        }
    }

    private fun requestImageReadPermission() {
        val permissions = when {
            Build.VERSION.SDK_INT >= 34 -> arrayOf(Manifest.permission.READ_MEDIA_IMAGES, "android.permission.READ_MEDIA_VISUAL_USER_SELECTED")
            Build.VERSION.SDK_INT >= 33 -> arrayOf(Manifest.permission.READ_MEDIA_IMAGES)
            else -> arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
        }
        requestPermissions(permissions, galleryPermissionRequest)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == galleryPermissionRequest) {
            val granted = hasImageReadPermission()
            runOnUiThread {
                webView.evaluateJavascript("window.onGalleryPermissionResult && window.onGalleryPermissionResult($granted);", null)
            }
        }
    }

    @Deprecated("Deprecated in Android, retained for broad WebView compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != pickRequest) return
        val callback = filePathCallback ?: return
        filePathCallback = null
        selectedUris.clear()
        if (resultCode == RESULT_OK && data != null) {
            val clip = data.clipData
            if (clip != null) {
                for (i in 0 until clip.itemCount) selectedUris.add(clip.getItemAt(i).uri)
            } else data.data?.let { selectedUris.add(it) }
            val flags = data.flags and (Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
            selectedUris.forEach { uri ->
                try { contentResolver.takePersistableUriPermission(uri, flags) } catch (_: Exception) { }
            }
            // Sort selected document URIs newest-first when the provider exposes modification time.
            // Keep this same order for the WebView FileList and native URI index mapping.
            val modified = selectedUris.associateWith { uri ->
                try {
                    contentResolver.query(uri, arrayOf(android.provider.DocumentsContract.Document.COLUMN_LAST_MODIFIED), null, null, null)?.use { c ->
                        if (c.moveToFirst()) c.getLong(0) else 0L
                    } ?: 0L
                } catch (_: Exception) { 0L }
            }
            selectedUris.sortWith(compareByDescending<Uri> { modified[it] ?: 0L }.thenBy { it.toString() })
        }
        callback.onReceiveValue(if (selectedUris.isEmpty()) null else selectedUris.toTypedArray())
    }

    inner class AndroidBridge {
        @JavascriptInterface
        fun hasGalleryPermission(): Boolean = hasImageReadPermission()

        @JavascriptInterface
        fun requestGalleryPermission() {
            runOnUiThread { requestImageReadPermission() }
        }

        @JavascriptInterface
        fun getGalleryImages(sortKey: String, offset: Int, limit: Int): String {
            if (!hasImageReadPermission()) return "{\"items\":[],\"error\":\"permission\"}"
            val items = JSONArray()
            val safeOffset = offset.coerceAtLeast(0)
            val safeLimit = limit.coerceIn(1, 200)
            val order = when (sortKey) {
                "date_asc" -> "${MediaStore.Images.Media.DATE_TAKEN} ASC, ${MediaStore.Images.Media.DATE_ADDED} ASC"
                "name_asc" -> "${MediaStore.Images.Media.DISPLAY_NAME} COLLATE NOCASE ASC"
                "name_desc" -> "${MediaStore.Images.Media.DISPLAY_NAME} COLLATE NOCASE DESC"
                "size_desc" -> "${MediaStore.Images.Media.SIZE} DESC"
                "size_asc" -> "${MediaStore.Images.Media.SIZE} ASC"
                else -> "${MediaStore.Images.Media.DATE_TAKEN} DESC, ${MediaStore.Images.Media.DATE_ADDED} DESC"
            }
            val projection = arrayOf(
                MediaStore.Images.Media._ID,
                MediaStore.Images.Media.DISPLAY_NAME,
                MediaStore.Images.Media.DATE_TAKEN,
                MediaStore.Images.Media.DATE_ADDED,
                MediaStore.Images.Media.DATE_MODIFIED,
                MediaStore.Images.Media.SIZE,
                MediaStore.Images.Media.MIME_TYPE
            )
            val collection = MediaStore.Images.Media.EXTERNAL_CONTENT_URI
            try {
                contentResolver.query(collection, projection, null, null, order)?.use { c ->
                    val idCol = c.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
                    val nameCol = c.getColumnIndexOrThrow(MediaStore.Images.Media.DISPLAY_NAME)
                    val takenCol = c.getColumnIndexOrThrow(MediaStore.Images.Media.DATE_TAKEN)
                    val addedCol = c.getColumnIndexOrThrow(MediaStore.Images.Media.DATE_ADDED)
                    val modifiedCol = c.getColumnIndexOrThrow(MediaStore.Images.Media.DATE_MODIFIED)
                    val sizeCol = c.getColumnIndexOrThrow(MediaStore.Images.Media.SIZE)
                    val mimeCol = c.getColumnIndexOrThrow(MediaStore.Images.Media.MIME_TYPE)
                    var rowIndex = 0
                    while (c.moveToNext() && items.length() < safeLimit) {
                        if (rowIndex++ < safeOffset) continue
                        val id = c.getLong(idCol)
                        val uri = Uri.withAppendedPath(collection, id.toString())
                        val thumb = createGalleryThumbnail(uri, id) ?: continue
                        val taken = c.getLong(takenCol)
                        val added = c.getLong(addedCol)
                        val modified = c.getLong(modifiedCol)
                        items.put(JSONObject().apply {
                            put("id", id.toString())
                            put("name", c.getString(nameCol) ?: "image_$id.jpg")
                            put("dateTaken", taken)
                            put("dateAdded", added)
                            put("dateModified", modified)
                            put("dateSort", if (taken > 0) taken else added * 1000L)
                            put("size", c.getLong(sizeCol))
                            put("mime", c.getString(mimeCol) ?: "image/jpeg")
                            put("thumb", thumb)
                        })
                    }
                }
                return JSONObject().put("items", items).toString()
            } catch (e: SecurityException) {
                return "{\"items\":[],\"error\":\"permission\"}"
            } catch (e: Exception) {
                return JSONObject().put("items", items).put("error", e.message ?: "gallery_error").toString()
            }
        }

        private fun createGalleryThumbnail(uri: Uri, id: Long): String? {
            var bitmap: Bitmap? = null
            return try {
                bitmap = if (Build.VERSION.SDK_INT >= 29) {
                    try { contentResolver.loadThumbnail(uri, Size(240, 240), CancellationSignal()) }
                    catch (_: Exception) { null }
                } else {
                    @Suppress("DEPRECATION")
                    try { MediaStore.Images.Thumbnails.getThumbnail(contentResolver, id, MediaStore.Images.Thumbnails.MINI_KIND, null) }
                    catch (_: Exception) { null }
                }
                if (bitmap == null) {
                    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                    contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
                    val sample = maxOf(1, maxOf(bounds.outWidth, bounds.outHeight) / 360)
                    val options = BitmapFactory.Options().apply { inSampleSize = sample.coerceAtLeast(1) }
                    bitmap = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, options) }
                }
                val image = bitmap ?: return null
                val output = java.io.ByteArrayOutputStream()
                image.compress(Bitmap.CompressFormat.JPEG, 72, output)
                Base64.encodeToString(output.toByteArray(), Base64.NO_WRAP)
            } catch (_: Exception) { null }
            finally { if (bitmap != null && !bitmap!!.isRecycled) bitmap!!.recycle() }
        }

        @JavascriptInterface
        fun setGallerySelection(idsJson: String): Boolean {
            return try {
                val ids = JSONArray(idsJson)
                val next = mutableListOf<Uri>()
                for (i in 0 until ids.length()) {
                    val id = ids.optString(i)
                    if (id.isNotBlank()) next.add(Uri.withAppendedPath(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id))
                }
                selectedUris.clear()
                selectedUris.addAll(next)
                true
            } catch (_: Exception) { false }
        }

        @JavascriptInterface
        fun getImageExifDate(index: Int): String {
            return try {
                val uri = selectedUris.getOrNull(index) ?: return ""
                contentResolver.openInputStream(uri)?.use { stream ->
                    val exif = ExifInterface(stream)
                    exif.getAttribute(ExifInterface.TAG_DATETIME_ORIGINAL)
                        ?: exif.getAttribute(ExifInterface.TAG_DATETIME_DIGITIZED)
                        ?: exif.getAttribute(ExifInterface.TAG_DATETIME)
                        ?: ""
                } ?: ""
            } catch (_: Exception) { "" }
        }
        @JavascriptInterface
        fun saveImage(index: Int, dataUrl: String, outputName: String, replaceOriginal: Boolean): Boolean {
            return try {
                val comma = dataUrl.indexOf(',')
                if (comma < 0) return false
                val bytes = Base64.decode(dataUrl.substring(comma + 1), Base64.DEFAULT)
                if (replaceOriginal) {
                    val uri = selectedUris.getOrNull(index) ?: return false
                    val stream = contentResolver.openOutputStream(uri, "wt") ?: return false
                    stream.use { it.write(bytes); it.flush() }
                } else {
                    val values = ContentValues().apply {
                        put(MediaStore.Images.Media.DISPLAY_NAME, outputName)
                        put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                        put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/TarikhNegar")
                    }
                    val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return false
                    contentResolver.openOutputStream(uri, "w")?.use { it.write(bytes); it.flush() } ?: return false
                }
                true
            } catch (_: IOException) { false } catch (_: SecurityException) { false } catch (_: Exception) { false }
        }

        /**
         * Process the selected image natively. This deliberately avoids WebView canvas.toBlob()
         * and Base64 transfer, which can stall on some Android WebView builds until the page is
         * touched or invalidated. Only one full-resolution bitmap is held at a time.
         */
        @JavascriptInterface
        fun processImage(
            index: Int,
            dateLabel: String,
            outputName: String,
            replaceOriginal: Boolean,
            colorHex: String,
            portraitSizeValue: Int,
            landscapeSizeValue: Int,
            position: String,
            shadow: Boolean,
            portraitX: Double,
            portraitY: Double,
            landscapeX: Double,
            landscapeY: Double
        ): Boolean {
            var decoded: Bitmap? = null
            var oriented: Bitmap? = null
            var output: Bitmap? = null
            var createdUri: Uri? = null
            return try {
                val sourceUri = selectedUris.getOrNull(index) ?: return false
                val rotationAndFlip = try {
                    contentResolver.openInputStream(sourceUri)?.use { stream ->
                        val exif = ExifInterface(stream)
                        Pair(exif.rotationDegrees, exif.isFlipped)
                    } ?: Pair(0, false)
                } catch (_: Exception) { Pair(0, false) }

                decoded = contentResolver.openInputStream(sourceUri)?.use { stream ->
                    BitmapFactory.decodeStream(stream)
                } ?: return false

                val matrix = Matrix()
                if (rotationAndFlip.first != 0) matrix.postRotate(rotationAndFlip.first.toFloat())
                if (rotationAndFlip.second) matrix.postScale(-1f, 1f)
                oriented = if (!matrix.isIdentity) {
                    Bitmap.createBitmap(decoded!!, 0, 0, decoded!!.width, decoded!!.height, matrix, true)
                } else decoded

                output = if (oriented!!.isMutable) oriented else oriented!!.copy(Bitmap.Config.ARGB_8888, true)
                val bitmap = output ?: return false
                val canvas = Canvas(bitmap)
                val portrait = bitmap.height > bitmap.width
                val selectedFontSize = if (portrait) portraitSizeValue else landscapeSizeValue
                val fontPx = (selectedFontSize.coerceIn(14, 60) * bitmap.width / 1000f).coerceAtLeast(1f)
                val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = try { Color.parseColor(colorHex) } catch (_: Exception) { Color.WHITE }
                    this.textSize = fontPx
                    typeface = Typeface.create("sans-serif", Typeface.BOLD)
                    if (shadow) setShadowLayer(fontPx * .22f, 2f, 2f, Color.argb(190, 0, 0, 0))
                }
                val pad = maxOf(5f, fontPx * .16f)
                val textWidth = paint.measureText(dateLabel)
                // Select independent fine-position settings for portrait and landscape photos.
                // Positive X moves right; positive Y moves down. Clamp the final text fully inside the image.
                val dxPercent = if (portrait) portraitX else landscapeX
                val dyPercent = if (portrait) portraitY else landscapeY
                val baseX = if (position == "bl" || position == "tl") pad else bitmap.width - pad - textWidth
                val baseBaseline = if (position == "tr" || position == "tl") pad + fontPx else bitmap.height - pad - fontPx * .18f
                val movedX = baseX + (dxPercent.coerceIn(-20.0, 20.0) / 100.0 * bitmap.width).toFloat()
                val movedBaseline = baseBaseline + (dyPercent.coerceIn(-20.0, 20.0) / 100.0 * bitmap.height).toFloat()
                val minX = pad
                val maxX = (bitmap.width - pad - textWidth).coerceAtLeast(minX)
                val x = movedX.coerceIn(minX, maxX)
                val baseline = movedBaseline.coerceIn(fontPx, bitmap.height - pad)
                canvas.drawText(dateLabel, x, baseline, paint)
                paint.clearShadowLayer()

                if (replaceOriginal) {
                    val stream = contentResolver.openOutputStream(sourceUri, "wt") ?: return false
                    stream.use { if (!bitmap.compress(Bitmap.CompressFormat.JPEG, 96, it)) throw IOException("JPEG compression failed") }
                } else {
                    val values = ContentValues().apply {
                        put(MediaStore.Images.Media.DISPLAY_NAME, outputName)
                        put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                        if (Build.VERSION.SDK_INT >= 29) {
                            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/TarikhNegar")
                            put(MediaStore.Images.Media.IS_PENDING, 1)
                        }
                    }
                    createdUri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return false
                    contentResolver.openOutputStream(createdUri!!, "w")?.use {
                        if (!bitmap.compress(Bitmap.CompressFormat.JPEG, 96, it)) throw IOException("JPEG compression failed")
                    } ?: throw IOException("Could not open output")
                    if (Build.VERSION.SDK_INT >= 29) {
                        val ready = ContentValues().apply { put(MediaStore.Images.Media.IS_PENDING, 0) }
                        contentResolver.update(createdUri!!, ready, null, null)
                    }
                }
                true
            } catch (_: Exception) {
                try { createdUri?.let { contentResolver.delete(it, null, null) } } catch (_: Exception) { }
                false
            } finally {
                if (output != null) output?.recycle()
                if (oriented != null && oriented !== output && oriented !== decoded) oriented?.recycle()
                if (decoded != null && decoded !== output && decoded !== oriented) decoded?.recycle()
            }
        }

        @JavascriptInterface
        fun setProcessingActive(active: Boolean) {
            if (active) {
                try {
                    val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
                    if (processingWakeLock == null) {
                        processingWakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "$packageName:TarikhNegarProcessing")
                    }
                    if (processingWakeLock?.isHeld != true) processingWakeLock?.acquire(4 * 60 * 60 * 1000L)
                } catch (_: Exception) { }
                try {
                    val serviceIntent = Intent(this@MainActivity, ProcessingForegroundService::class.java)
                    if (Build.VERSION.SDK_INT >= 26) startForegroundService(serviceIntent) else startService(serviceIntent)
                } catch (_: Exception) { }
                runOnUiThread { window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON) }
            } else {
                try { if (processingWakeLock?.isHeld == true) processingWakeLock?.release() } catch (_: Exception) { }
                try { stopService(Intent(this@MainActivity, ProcessingForegroundService::class.java)) } catch (_: Exception) { }
                runOnUiThread { window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON) }
            }
        }

        @JavascriptInterface
        fun requestNotificationPermission() {
            runOnUiThread {
                if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), notificationRequest)
                }
            }
        }

        @JavascriptInterface
        fun notifyProcessingComplete(done: Int, skipped: Int, failed: Int, remaining: Int) {
            try {
                if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) return
                val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                val title = if (remaining == 0 && skipped == 0 && failed == 0) "پردازش عکس‌ها کامل شد" else "پردازش عکس‌ها پایان یافت"
                val detail = "$done عکس ذخیره شد؛ $skipped بدون تاریخ، $failed ناموفق، $remaining باقی‌مانده"
                val launchIntent = packageManager.getLaunchIntentForPackage(packageName)
                val pending = launchIntent?.let {
                    PendingIntent.getActivity(this@MainActivity, 0, it, PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0))
                }
                val builder = if (Build.VERSION.SDK_INT >= 26) android.app.Notification.Builder(this@MainActivity, notificationChannelId) else android.app.Notification.Builder(this@MainActivity)
                builder.setSmallIcon(applicationInfo.icon)
                    .setContentTitle(title)
                    .setContentText(detail)
                    .setStyle(android.app.Notification.BigTextStyle().bigText(detail))
                    .setAutoCancel(true)
                if (pending != null) builder.setContentIntent(pending)
                manager.notify(2207, builder.build())
            } catch (_: Exception) { }
        }

        @JavascriptInterface
        fun selectedCount(): Int = selectedUris.size

        @JavascriptInterface
        fun setKeepScreenOn(enabled: Boolean) {
            runOnUiThread {
                if (enabled) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            }
        }

        @JavascriptInterface
        fun isBatterySetupDone(): Boolean {
            val prefs = getSharedPreferences("tarikhnegar_settings", Context.MODE_PRIVATE)
            val manuallyConfirmed = prefs.getBoolean("battery_setup_done", false)
            val systemExempt = try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    (getSystemService(Context.POWER_SERVICE) as PowerManager).isIgnoringBatteryOptimizations(packageName)
                } else true
            } catch (_: Exception) { false }
            if (systemExempt && !manuallyConfirmed) prefs.edit().putBoolean("battery_setup_done", true).apply()
            return manuallyConfirmed || systemExempt
        }

        @JavascriptInterface
        fun markBatterySetupDone() {
            getSharedPreferences("tarikhnegar_settings", Context.MODE_PRIVATE)
                .edit().putBoolean("battery_setup_done", true).apply()
        }

        @JavascriptInterface
        fun openBatterySettings() {
            runOnUiThread {
                try {
                    startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                } catch (_: Exception) {
                    try {
                        startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                            data = Uri.parse("package:$packageName")
                        })
                    } catch (_: Exception) {
                        Toast.makeText(this@MainActivity, "باز کردن تنظیمات باتری ممکن نشد", Toast.LENGTH_LONG).show()
                    }
                }
            }
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(notificationChannelId, "گزارش پردازش عکس‌ها", NotificationManager.IMPORTANCE_DEFAULT).apply {
                description = "اعلان پایان پردازش عکس‌ها در تاریخ‌نگار فارسی"
            }
            (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
    }

    override fun onResume() {
        super.onResume()
        if (::webView.isInitialized) {
            webView.onResume()
        }
    }

    override fun onDestroy() {
        try { if (processingWakeLock?.isHeld == true) processingWakeLock?.release() } catch (_: Exception) { }
        try { stopService(Intent(this, ProcessingForegroundService::class.java)) } catch (_: Exception) { }
        if (::webView.isInitialized) {
            window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            webView.removeJavascriptInterface("AndroidBridge")
            webView.destroy()
        }
        super.onDestroy()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        webView.saveState(outState)
        super.onSaveInstanceState(outState)
    }

    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }
}
